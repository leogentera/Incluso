//TODO remove this module
(function(){
    var module = angular.module('GlobalAppConstants', []);

    module.constant('MoodleIds', {
        "forum":64,
        "retoMultiple":139
    });
})();