﻿(function () {

    namespace('models');

    // --------------- Model  ---------------

    models.Profile = Backbone.Model.extend({

        //urlRoot: API_RESOURCE.format('Referral/single'),
    });

}).call(this);
