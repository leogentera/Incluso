angular
    .module('incluso.programa.chatcontroller', ['ngSanitize'])
    .controller('programaChatController', [
        '$q',
        '$scope',
        '$location',
        '$routeParams',
        '$timeout',
        '$rootScope',
        '$http',
        '$anchorScroll',
        '$modal',
        function ($q, $scope, $location, $routeParams, $timeout, $rootScope, $http, $anchorScroll, $modal) {
            $scope.$emit('ShowPreloader');

            //################################# ENTRY POINT ################################
            $scope.validateConnection(initController, offlineCallback);

            function initController() {

                _timeout = $timeout;
                _httpFactory = $http;
                $scope.setToolbar($location.$$path, "Cabina de Soporte");
                $rootScope.showFooter = false;
                $rootScope.showFooterRocks = false;
                $rootScope.showStage1Footer = false;
                $rootScope.showStage2Footer = false;
                $rootScope.showStage3Footer = false;

                //var _usercourse = JSON.parse(localStorage.getItem('usercourse'));
                var userId = localStorage.getItem('userId');
                var currentUser = JSON.parse(localStorage.getItem('CurrentUser'));
                $scope.senderId = currentUser.userId;
                $scope.messages = JSON.parse(localStorage.getItem('userChat/' + currentUser.userId));
                $scope.currentMessage = "";
                $location.hash("anchor-bottom");

                var interval = setInterval(getMessages, 60000); //Poll Messages continuously.

                $scope.$on('$routeChangeStart', function (next, current) {//If the user Leaves, kill setInterval.
                    clearInterval(interval);
                });

                function getMessages() {
                    $scope.validateConnection(function () {
                        moodleFactory.Services.GetUserChat(currentUser.userId, currentUser.token, getUserRefreshChatCallback, function (obj) {
                                                $scope.$emit('HidePreloader');
                                                if (obj && obj.statusCode && obj.statusCode == 408) {//Request Timeout
                                                  $timeout(function () {
                                                    $location.path('/Offline'); //This behavior could change
                                                  }, 1);
                                                } else {//Another kind of Error happened
                                                  $timeout(function () {
                                                      console.log("Another kind of Error happened");
                                                      $scope.$emit('HidePreloader');
                                                      $location.path('/connectionError');
                                                  }, 1);
                                                }
                                            }, true);
                    }, function () {
                    });
                }

                $(".typing-section textarea").keypress(function () {
                    $(".typing-section textarea").focus();
                });

                // Get Chat conversation
                moodleFactory.Services.GetUserChat(currentUser.userId, currentUser.token, getUserRefreshChatCallback, function (obj) {
                                $scope.$emit('HidePreloader');
                                if (obj && obj.statusCode && obj.statusCode == 408) {//Request Timeout
                                  $timeout(function () {
                                    $location.path('/Offline'); //This behavior could change
                                  }, 1);
                                } else {//Another kind of Error happened
                                  $timeout(function () {
                                      console.log("Another kind of Error happened");
                                      $scope.$emit('HidePreloader');
                                      $location.path('/connectionError');
                                  }, 1);
                                }
                            }, true);

                function getUserRefreshChatCallback() {
                    $scope.$emit('HidePreloader'); //hide preloader
                    localStorage.setItem("chatRead/" + currentUser.userId, "true");   //Turn-off Chat Bubble.
                    var messages = localStorage.getItem('userChat/' + currentUser.userId); //Get all messages posted.

                    if (messages) {
                        $scope.messages = JSON.parse(messages);
                    } else {//null
                        $scope.messages = [];
                    }

                    _setLocalStorageItem('numMessages/' + currentUser.userId, $scope.messages.length);
                }

                // METHOD THAT RUNS WHEN USER SENDS A NEW CHAT POST
                $scope.sendMessage = function () {
                    var newMessage;

                    $scope.validateConnection(function () {

                        if ($scope.currentMessage.trim() != "") {//If there is currently some text...
                            triggerAndroidKeyboardHide();

                            // 1) Create Model for User Post...
                            newMessage = {
                                messagetext: $scope.currentMessage,
                                messagesenderid: currentUser.userId,
                                messagedate: new Date()
                            };

                            /* time out to avoid android lag on fully hiding keyboard */
                            $timeout(function () {
                                // 2) Save User Post in LS...
                                $scope.messages.push(newMessage);
                                $scope.currentMessage = ""; //Clean Text Area
                                _setLocalStorageItem('userChat/' + currentUser.userId, JSON.stringify($scope.messages));
                                $anchorScroll();

                                // 3) Save User Post Remotely.
                                moodleFactory.Services.PutUserChat(currentUser.userId, newMessage, getUserChatCallback, function (obj) {
                                                $scope.$emit('HidePreloader');
                                                if (obj && obj.statusCode && obj.statusCode == 408) {//Request Timeout
                                                  $timeout(function () {
                                                    $location.path('/Offline'); //This behavior could change
                                                  }, 1);
                                                } else {//Another kind of Error happened
                                                  $timeout(function () {
                                                      console.log("Another kind of Error happened");
                                                      $scope.$emit('HidePreloader');
                                                      $location.path('/connectionError');
                                                  }, 1);
                                                }
                                            });

                                // 4) Create Model for Automated Message
                                var firstTimeMessage = JSON.parse(localStorage.getItem("drupal/content/chat_generic_message")).node.chat_instructions;

                                newMessage = {
                                    messagetext: firstTimeMessage,
                                    messagesenderid: currentUser.userId, //Dev  Prod:350
                                    sendAsCouch: true,
                                    messagedate: new Date()
                                };

                                /* time out to avoid android lag on fully hiding keyboard */
                                $timeout(function () {
                                    // 5) Save Generic Message in LS...
                                    $scope.messages.push(newMessage);
                                    _setLocalStorageItem('userChat/' + currentUser.userId, JSON.stringify($scope.messages));
                                    $anchorScroll();

                                    // 6) Save Automated Message Remotely.
                                    moodleFactory.Services.PutUserChat(currentUser.userId, newMessage, getUserChatCallback, function (obj) {
                                                $scope.$emit('HidePreloader');
                                                if (obj && obj.statusCode && obj.statusCode == 408) {//Request Timeout
                                                  $timeout(function () {
                                                    $location.path('/Offline'); //This behavior could change
                                                  }, 1);
                                                } else {//Another kind of Error happened
                                                  $timeout(function () {
                                                      console.log("Another kind of Error happened");
                                                      $scope.$emit('HidePreloader');
                                                      $location.path('/connectionError');
                                                  }, 1);
                                                }
                                            });
                                }, 1000);

                            }, 1000);
                        }

                    }, offlineCallback);
                };

                function getUserChatCallback() {
                    _setLocalStorageItem('numMessages/' + currentUser.userId, $scope.messages.length);
                }

                function triggerAndroidKeyboardHide() {
                    angular.element('#chatMessages').trigger('tap');
                    $anchorScroll();
                }
            }

            function offlineCallback() {
                $timeout(function () {
                    $location.path("/Offline");
                }, 1000);
            }
        }
    ]);
