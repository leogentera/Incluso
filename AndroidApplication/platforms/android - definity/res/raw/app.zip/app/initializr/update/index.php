<?php	
include_once('get_templates.php');
	


get_template("http://app.incluso.com.mx/drupal/es/login", "/../Templates/public/login.html");
get_template("http://app.incluso.com.mx/drupal/stage/conocete", "/../Templates/programa/conocete.html");


?>